# Batch Helpers — Cara Cepat Menjalankan

## File yang disediakan
- `start_server.bat` — Menjalankan server (aktifkan venv + set API_KEY).
- `create_invoice.bat` — Membuat contoh invoice dan otomatis membuka HTML-nya.
- `open_invoice.bat` — Mengambil & membuka HTML berdasarkan ID yang sudah ada.

> Letakkan ketiga file ini di **root folder proyek** (sejajar dengan folder `app`).

## Cara pakai
1) **Jalankan server** — Double-click `start_server.bat` (biarkan jendela server terbuka).
2) **Buat invoice** — Double-click `create_invoice.bat` → menulis `data.json`, memanggil API, mengekstrak `id`, lalu membuka HTML.
3) **(Opsional) Buka invoice tertentu** — Jalankan `open_invoice.bat inv_XXXXXX` atau tanpa argumen → diminta memasukkan ID.

## Catatan
- Jika belum ada virtual env, buat dulu di CMD: `python -m venv .venv` lalu `pip install -r requirements.txt`.
- Default `API_KEY`: `demo_merchant_key`. Ubah di file `.bat` jika diperlukan.
- Data in-memory akan hilang saat server berhenti. Jalankan `create_invoice.bat` untuk membuat ID baru.
